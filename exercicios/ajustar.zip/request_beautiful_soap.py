import requests
import codecs
from bs4 import BeautifulSoup


url = 'http://loterias.caixa.gov.br/wps/portal/loterias/landing/lotofacil'
response = requests.get(url)
html = response.content

soup = BeautifulSoup(html, "html.parser")

#url = requests.get("http://loterias.caixa.gov.br/wps/portal/loterias/landing/lotofacil")
#html = str(url.content).encode('utf-8')
#soup = BeautifulSoup(url.text.encode('utf-8'), 'html.parser')

print(soup.prettify().encode('utf-8'))
#print(soup.title.string)

