import requests
 
def cria_lista_links(content):
    links = []
    for line in content.split('</p>'):
        index = line.find('class="title ')
        if index != -1:
            href_start = line.find('href="', index) + 6
            href_end = line.find('"', href_start)
            links.append(line[href_start:href_end])
    return links
 
#r = requests.get("http://www.reddit.com/r/programming")
#print '\n'.join(cria_lista_links(r.content))

def replace_all(text, dic):
    for i, j in dic.iteritems():
        text = text.replace(i, j)
    return text

  
def intrucoes_replace_all():
  # our text the replacement will take place
  my_text = 'Hello everybody.'
  
  # our dictionary with our key:values.
  # we want to replace 'H' with '|-|'
  # 'e' with '3' and 'o' with '0'
  reps = {'H':'|-|', 'e':'3', 'o':'0'}
  
  # bind the returned text of the method
  # to a variable and print it
  txt = replace_all(my_text, reps)
  print(txt)    # it prints '|-|3ll0 3v3ryb0dy'
  # of course we can print the result
  # at once with:
  # print replace_all(my_text, reps)


def busca_resultado_lotofacil(content):
    links = []
    trocar = {'\n':'', '\t':'', '<td>':'', '</td>':' - ','\r':'', '<tr>':'', '</tr>':''}
    for line in content.split('</tbody>'):
        index = line.find('class="simple-table lotofacil')
        if index != -1:
            href_start = line.find('<tbody>', index) + 7
            href_end = line.find('</tbody>', href_start)
            #links.append(line[href_start:href_end].replace('\t',''))
            links.append(replace_all(line[href_start:href_end],trocar))
    return links
 

r = requests.get("http://loterias.caixa.gov.br/wps/portal/loterias/landing/lotofacil")
print(busca_resultado_lotofacil(r.content))