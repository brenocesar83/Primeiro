import requests
from bs4 import BeautifulSoup

payload = {'username': 'brenocesar@gmail.com', 'password': '981086'}
url = 'https://www.buxfer.com/login?next=%2Fhome'
pagina = requests.post(url, data=payload)

print(pagina.status_code)
html = pagina.text
soup = BeautifulSoup(html, "html.parser") #html.parser html5lib lxml
print("Titulo da Pagina: ",soup.title.encode('utf-8')) #utf-8 latin-1 ascii