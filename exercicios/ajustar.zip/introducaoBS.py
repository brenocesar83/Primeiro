import requests
from bs4 import BeautifulSoup
pagina = requests.get("http://loterias.caixa.gov.br/wps/portal/loterias/landing/lotofacil")
print(pagina.status_code)
html = pagina.text
soup = BeautifulSoup(html, "html.parser") #html.parser html5lib lxml
print("Titulo da Pagina: ",soup.title.encode('utf-8')) #utf-8 latin-1 ascii
samples = soup.find("table", "simple-table")
#print(samples)
titulo = soup.find("div", "title-bar clearfix")
#titulo = titulo.text.replace("\n", " ")
#print(titulo.encode('utf-8'))

def imprimir_content(content, tag):
  rows = []
  for row in content.find_all(tag):
    rows.append(row.text.strip())
  return rows


print(imprimir_content(titulo,"span"))
print(imprimir_content(samples,"td"))
